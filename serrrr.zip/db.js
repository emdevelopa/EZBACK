// db.js
const admin = require("./firebase");
const firestore = admin.firestore();

module.exports = firestore;
